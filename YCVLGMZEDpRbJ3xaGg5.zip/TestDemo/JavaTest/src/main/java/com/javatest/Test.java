package com.javatest;

import java.sql.Time;

public class Test {

    public static void main(String[] args) {
        String str = "23:50:15";
        Time time = Time.valueOf(str);

        Time time1=new Time(System.currentTimeMillis());
        String k2=time1.toString();

        System.out.println("=====time="+time);
        System.out.println("=====time1="+time1+"   k2="+k2);

    }

}
