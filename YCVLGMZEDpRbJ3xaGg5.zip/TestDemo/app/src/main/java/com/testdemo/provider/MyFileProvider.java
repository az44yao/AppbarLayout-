package com.testdemo.provider;

import androidx.core.content.FileProvider;

/**
 * Title:自定义FileProvider,解决FileProvider引用重复的问题
 * description:
 * autor:pei
 * created on 2020/2/21
 */
public class MyFileProvider extends FileProvider {

}
