package com.testdemo.other;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.testdemo.R;

/**
 * Title:
 * description:
 * autor:pei
 * created on 2020/9/2
 */
public class ChildFragmentTwo extends Fragment {

    private View mLayoutView;
    private Context mContext;
    private TextView mTvTestA;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext=context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mLayoutView = inflater.inflate(R.layout.fragment_b, container, false);

        initView();
        initData();
        setListener();

        return mLayoutView;
    }

    private void initView(){
        mTvTestA=mLayoutView.findViewById(R.id.tv_a);
    }

    private void initData(){
        Bundle bundle=getArguments();
        String value="";
        if(bundle!=null) {
            value = bundle.getString("A");
        }
        mTvTestA.setText("子界面二");
    }

    private void setListener(){}

}
