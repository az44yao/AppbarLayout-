package com.testdemo.example_ui;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.testdemo.R;
import com.testdemo.other.FragmentA;
import com.testdemo.other.FragmentB;
import com.testdemo.other.FragmentC;
import java.util.ArrayList;
import java.util.List;

/**
 * Title:
 * description:
 * autor:pei
 * created on 2020/7/10
 */
public class TempActivity extends AppCompatActivity implements View.OnClickListener,RadioGroup.OnCheckedChangeListener{

    private RadioGroup mRgTabBar;
    private RadioButton mRbHome;
    private RadioButton mRbNews;
    private RadioButton mRbChoose;

    private static final String HOME_FRAGMENT="HomeFragment";
    private static final String NEWS_FRAGMENT="NewsFragment";
    private static final String CHOOSE_FRAGMENT="ChooseFragment";

    private List<String>mFrdagmentTagList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp);

        //初始化控件
        initView();
        //初始化数据
        initData();
        //控件监听
        setListener();
    }

    /**初始化控件**/
    private void initView(){
        mRgTabBar=findViewById(R.id.rg_tab_bar);
        mRbHome=findViewById(R.id.rb_home);
        mRbNews=findViewById(R.id.rb_news);
        mRbChoose=findViewById(R.id.rb_choose);
    }

    /**初始化数据**/
    private void initData(){
        mFrdagmentTagList=new ArrayList<>();
        mFrdagmentTagList.add(HOME_FRAGMENT);
        mFrdagmentTagList.add(NEWS_FRAGMENT);
        mFrdagmentTagList.add(CHOOSE_FRAGMENT);
        //初始化fragment
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        for (String tag : mFrdagmentTagList) {
            Fragment fragment = manager.findFragmentByTag(tag);
            if(fragment==null){
                switch (tag) {
                    case HOME_FRAGMENT:
                        fragment=new FragmentA();
                        //首页默认显示
                        transaction.show(fragment);
                        mRbHome.setChecked(true);
                        break;
                    case NEWS_FRAGMENT:
                        fragment=new FragmentB();
                        transaction.hide(fragment);
                        mRbNews.setChecked(false);
                        break;
                    case CHOOSE_FRAGMENT:
                        fragment=new FragmentC();
                        transaction.hide(fragment);
                        mRbChoose.setChecked(false);
                        break;
                    default:
                        break;
                }
            }
            if(!fragment.isAdded()) {
                transaction.add(R.id.frame_layout, fragment, tag);
            }
        }
        //提交事务
        transaction.commitAllowingStateLoss();
    }

    /**控件监听**/
    private void setListener(){
        mRgTabBar.setOnCheckedChangeListener(this);
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId) {
            case R.id.rb_home:
                showFragmentByTag(HOME_FRAGMENT);
                break;
            case R.id.rb_news:
                showFragmentByTag(NEWS_FRAGMENT);
                break;
            case R.id.rb_choose:
                showFragmentByTag(CHOOSE_FRAGMENT);
                break;
            default:
                break;
        }
    }

    private void showFragmentByTag(String tag){
        mRbHome.setChecked(false);
        mRbNews.setChecked(false);
        mRbChoose.setChecked(false);
        switch (tag) {
            case HOME_FRAGMENT:
                mRbHome.setChecked(true);
                break;
            case NEWS_FRAGMENT:
                mRbNews.setChecked(true);
                break;
            case CHOOSE_FRAGMENT:
                mRbChoose.setChecked(true);
                break;
            default:
                break;
        }
        startFragment(tag);
    }

    private void startFragment(String tag){
        //初始化fragment
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        for (String ftag : mFrdagmentTagList) {
            Fragment fragment = manager.findFragmentByTag(ftag);
            if(ftag.equals(tag)) {
                transaction.show(fragment);
            }else{
                transaction.hide(fragment);
            }
        }
        //提交事务
        transaction.commitAllowingStateLoss();
    }


}
