package com.testdemo.other;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.tabs.TabLayout;
import com.testdemo.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Title:
 * description:
 * autor:pei
 * created on 2020/9/2
 */
public class FragmentA extends Fragment {

    private View mLayoutView;
    private Context mContext;

    private TabLayout mTabLayout;
    private ViewPager mViewPager;

    private List<String> mTitleList;
    private List<Fragment> mFragmentList;
    private TempPagerAdapter mTempPagerAdapter;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext=context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mLayoutView = inflater.inflate(R.layout.fragment_a, container, false);

        initView();
        initData();
        setListener();

        return mLayoutView;
    }

    private void initView(){
        mTabLayout=mLayoutView.findViewById(R.id.tab_layout);
        mViewPager=mLayoutView.findViewById(R.id.view_pager);
    }

    private void initData(){
        //标题填充
        mTitleList = new ArrayList<>();
        mTitleList.add("子界面一");
        mTitleList.add("子界面二");
        //fragment填充
        mFragmentList = new ArrayList<>();
        mFragmentList.add(0, new ChildFragmentOne());
        mFragmentList.add(1, new ChildFragmentTwo());
        //viewPager设置
        mTempPagerAdapter = new TempPagerAdapter(getFragmentManager(), mFragmentList,mTitleList);
        mViewPager.setOffscreenPageLimit(mTitleList.size());// 设置预加载Fragment个数
        mViewPager.setAdapter(mTempPagerAdapter);
        mViewPager.setCurrentItem(0);// 设置当前显示标签页为第一页

        // 将ViewPager和TabLayout绑定
        mTabLayout.setupWithViewPager(mViewPager);
        // 设置tab文本的没有选中（第一个参数）和选中（第二个参数）的颜色
        mTabLayout.setTabTextColors(Color.GRAY,Color.RED);
    }

    private void setListener(){
        //viewPager页面滑动监听
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                mViewPager.setCurrentItem(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

}
