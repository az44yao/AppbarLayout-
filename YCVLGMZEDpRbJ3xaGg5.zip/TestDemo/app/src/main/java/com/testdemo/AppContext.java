package com.testdemo;

import com.app.ComContext;
import com.util.LogUtil;

public class AppContext extends ComContext {


    @Override
    public void onCreate() {
        super.onCreate();

        LogUtil.setDebug(true);

    }

}
