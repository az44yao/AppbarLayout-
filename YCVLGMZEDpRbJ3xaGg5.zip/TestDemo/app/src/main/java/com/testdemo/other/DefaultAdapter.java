package com.testdemo.other;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.testdemo.R;

import java.util.List;

/**
 * Title:
 * description:
 * autor:pei
 * created on 2020/9/2
 */
public class DefaultAdapter <T>extends RecyclerView.Adapter{

    protected Context mContext;
    protected View mLayoutView;
    protected List<T> mData;

    public DefaultAdapter(Context context,List<T>data){
        this.mContext=context;
        this.mData=data;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        mLayoutView= LayoutInflater.from(mContext).inflate(R.layout.item_one,parent,false);
        ViewHolder viewHolder=new ViewHolder(mLayoutView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        String name=mData.get(position).toString();
        ((ViewHolder)holder).mTvName.setText(name);
    }

    @Override
    public int getItemCount() {
        return mData==null?0:mData.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        TextView mTvName;

        public ViewHolder(View view) {
            super(view);
            mTvName=(TextView)view.findViewById(R.id.tv_text);
        }
    }

}
