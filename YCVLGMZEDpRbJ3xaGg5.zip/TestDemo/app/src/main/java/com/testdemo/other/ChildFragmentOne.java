package com.testdemo.other;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.testdemo.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Title:
 * description:
 * autor:pei
 * created on 2020/9/2
 */
public class ChildFragmentOne extends Fragment {

    private View mLayoutView;
    private Context mContext;
    private RecyclerView mRecyclerView;

    private List<String> mNameList;
    private DefaultAdapter mDefaultAdapter;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext=context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mLayoutView = inflater.inflate(R.layout.fragment_child_one, container, false);

        initView();
        initData();
        setListener();

        return mLayoutView;
    }

    private void initView(){
        mRecyclerView=mLayoutView.findViewById(R.id.rv);
    }

    private void initData(){
        mNameList=new ArrayList<>();
        for(int i=0;i<30;i++){
            mNameList.add("关注微信公众号：Android进击    position="+i);
        }

        mDefaultAdapter=new DefaultAdapter(mContext,mNameList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(mContext);
        layoutManager.setSmoothScrollbarEnabled(true);
        layoutManager.setAutoMeasureEnabled(true);
        //此行代码解决AppBarLayout+ViewPager+RecyclerView滑动冲突问题(要设置为true)
        mRecyclerView.setNestedScrollingEnabled(true);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mDefaultAdapter);
    }

    private void setListener(){}

}
