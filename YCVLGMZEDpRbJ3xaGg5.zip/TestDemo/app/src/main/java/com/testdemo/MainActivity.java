package com.testdemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.permision.PermissionHelper;
import com.testdemo.example_ui.TempActivity;
import com.util.LogUtil;
import kr.co.namee.permissiongen.PermissionFail;
import kr.co.namee.permissiongen.PermissionSuccess;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private static final int PERMISSION_CODE = 1234;

    private Button mButton1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //初始化控件
        initView();
        //初始化数据
        initData();
        //设置监听
        setListener();
        //申请权限
        requestPermission(MainActivity.PERMISSION_CODE);
    }

    private void requestPermission(int requestCode) {
        String permissions[] = {
                Manifest.permission.INTERNET,
                Manifest.permission.WRITE_SETTINGS,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE};
        PermissionHelper.getInstance().checkPermissions(permissions, requestCode, MainActivity.this);
    }

    @PermissionSuccess(requestCode = MainActivity.PERMISSION_CODE)
    public void requestSuccess() {
        //申请到权限后的处理
        //......

        LogUtil.i("=====权限申请成功======");
    }

    @PermissionFail(requestCode = MainActivity.PERMISSION_CODE)
    public void requestFail(){
        //未获取到权限的处理
        //......

        LogUtil.i("=====权限申请失败======");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        PermissionHelper.getInstance().onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void initView() {
        mButton1 = findViewById(R.id.btn1);
    }

    private void initData() {

    }

    private void setListener(){
        mButton1.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
       switch (v.getId()) {
           case R.id.btn1://跳转下一界面
               LogUtil.i("=====跳转下一界面====");

               Intent intent=new Intent(MainActivity.this, TempActivity.class);
               startActivity(intent);
               break;
           default:
               break;
       }
    }


}
