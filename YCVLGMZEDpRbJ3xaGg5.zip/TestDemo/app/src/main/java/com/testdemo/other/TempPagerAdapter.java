package com.testdemo.other;

import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.View;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.PagerTabStrip;
import com.app.ComContext;
import java.util.List;

/**
 * Title:
 * description:
 * autor:pei
 * created on 2020/9/2
 */
public class TempPagerAdapter extends FragmentPagerAdapter {

    private List<Fragment> mFragmentList;
    private List<String> mTitles;
    private int mColorId;
    private float mTextSize;

    public TempPagerAdapter(FragmentManager fm, List<Fragment> mFragmentList, List<String> mTitles) {
        super(fm);
        this.mFragmentList = mFragmentList;
        this.mTitles=mTitles;
    }

    /***
     * 设置PagerTabStrip字体颜色
     *
     * @param colorId: eg:R.color.red
     */
    public void setColorId(int colorId) {
        this.mColorId = colorId;
    }

    /**设置PagerTabStrip字体大小**/
    public void setTextSize(float textSize) {
        this.mTextSize = textSize;
    }

    /***
     * 设置PagerTabStrip下划线颜色
     * @param indicatorColor eg:R.color.red
     * @param pagerTabStrip  PagerTabStrip对象
     */
    public void setIndicatorColor(int indicatorColor, PagerTabStrip pagerTabStrip) {
        if (pagerTabStrip != null) {
            pagerTabStrip.setTabIndicatorColorResource(indicatorColor);
        }
    }

    @Override
    public Fragment getItem(int position) {
        // TODO Auto-generated method stub
        return mFragmentList == null ? null : mFragmentList.get(position);
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return mFragmentList == null ? 0 : mFragmentList.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        if(mTitles!=null&&!mTitles.isEmpty()){
            String title=mTitles.get(position);
            SpannableStringBuilder ssb = new SpannableStringBuilder(title);
            if(mColorId!=0){
                //设置字体颜色
                ForegroundColorSpan fcs = new ForegroundColorSpan(ContextCompat.getColor(ComContext.getInstance(),mColorId));
                ssb.setSpan(fcs, 0, ssb.length(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            if(mTextSize>0){
                //设置字体大小
                ssb.setSpan(new RelativeSizeSpan(mTextSize), 0, ssb.length(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            return ssb;
        }
        return null;
    }

    @Override
    public void destroyItem(View container, int position, Object object) {
        //      super.destroyItem(container, position, object);
    }
}
